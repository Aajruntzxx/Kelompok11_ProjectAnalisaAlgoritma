// ============================================================
// FILE: backtracking.cpp
// JUDUL: Implementasi Backtracking untuk 0/1 Knapsack Problem
// STUDI KASUS: Optimasi Pemilihan Barang pada Perusahaan Ekspedisi
// ============================================================

#include <iostream>
#include <vector>
#include <string>
#include <chrono>
#include <iomanip>

using namespace std;

// ============================================================
// STRUKTUR DATA BARANG
// Menyimpan atribut setiap barang yang akan dipilih
// ============================================================
struct Barang {
    string nama;   // Nama barang
    int berat;     // Berat barang (kg)
    int profit;    // Keuntungan/profit barang
};

// ============================================================
// VARIABEL GLOBAL
// ============================================================
int jumlahBarang;
int kapasitas;
vector<Barang> daftarBarang;

int profitTerbaik  = 0;    // Menyimpan profit solusi terbaik yang ditemukan
int nodesDikunjungi = 0;   // Counter jumlah node yang dikunjungi

vector<int> pilihanSaatIni;  // Barang yang sedang dipertimbangkan
vector<int> pilihanTerbaik;  // Barang pada solusi terbaik

// ============================================================
// FUNGSI: Tampilkan Indentasi (visualisasi kedalaman rekursi)
// Membantu mahasiswa memahami kedalaman pohon pencarian
// ============================================================
void tampilkanIndentasi(int level) {
    for (int i = 0; i < level; i++) cout << "  |  ";
}

// ============================================================
// FUNGSI REKURSIF: Backtracking
//
// Parameter:
//   - level       : Indeks barang yang sedang dipertimbangkan
//   - beratSaatIni: Total berat barang yang sudah dipilih
//   - profitSaatIni: Total profit barang yang sudah dipilih
//
// Cara Kerja:
//   1. Untuk setiap barang, coba DUA pilihan: AMBIL atau TIDAK AMBIL
//   2. Jika mengambil barang menyebabkan berat melebihi kapasitas → BATALKAN
//   3. Jika sudah mencapai semua barang → catat jika solusi ini lebih baik
//   4. Setelah menjelajahi satu cabang → BACKTRACK (kembali ke kondisi sebelumnya)
// ============================================================
void backtrack(int level, int beratSaatIni, int profitSaatIni) {
    // --------------------------------------------------------
    // BASE CASE: Sudah mempertimbangkan semua barang
    // --------------------------------------------------------
    if (level == jumlahBarang) {
        nodesDikunjungi++;

        // Perbarui solusi terbaik jika ditemukan profit yang lebih besar
        if (profitSaatIni > profitTerbaik) {
            profitTerbaik  = profitSaatIni;
            pilihanTerbaik = pilihanSaatIni;

            cout << string(50, '-') << "\n";
            cout << "[SOLUSI BARU DITEMUKAN!] Profit = " << profitTerbaik << "\n";
            cout << "Barang dipilih: ";
            for (int idx : pilihanTerbaik) cout << daftarBarang[idx].nama << " ";
            cout << "\n" << string(50, '-') << "\n";
        } else {
            tampilkanIndentasi(level);
            cout << "-> Leaf: profit=" << profitSaatIni
                 << " (tidak lebih baik dari " << profitTerbaik << ")\n";
        }
        return;
    }

    nodesDikunjungi++;

    // --------------------------------------------------------
    // CABANG KIRI: AMBIL barang ke-level
    // --------------------------------------------------------
    int beratBaru  = beratSaatIni  + daftarBarang[level].berat;
    int profitBaru = profitSaatIni + daftarBarang[level].profit;

    tampilkanIndentasi(level);
    cout << "+-[AMBIL] Barang " << daftarBarang[level].nama
         << " (berat=" << daftarBarang[level].berat
         << ", profit=" << daftarBarang[level].profit << ")"
         << " | Total berat=" << beratBaru
         << ", Total profit=" << profitBaru << "\n";

    // Periksa apakah berat masih dalam kapasitas
    if (beratBaru <= kapasitas) {
        // Masukkan barang ke dalam pilihan saat ini
        pilihanSaatIni.push_back(level);

        // Rekursi ke barang berikutnya (telusuri lebih dalam)
        backtrack(level + 1, beratBaru, profitBaru);

        // BACKTRACK: Keluarkan barang dari pilihan (batalkan keputusan)
        pilihanSaatIni.pop_back();

        tampilkanIndentasi(level);
        cout << "  [BACKTRACK] Kembali dari Barang " << daftarBarang[level].nama << "\n";
    } else {
        // Berat melebihi kapasitas → cabang ini dipangkas
        tampilkanIndentasi(level);
        cout << "  [BATALKAN] Berat " << beratBaru
             << " melebihi kapasitas " << kapasitas << " → Cabang dipangkas!\n";
    }

    // --------------------------------------------------------
    // CABANG KANAN: TIDAK AMBIL barang ke-level
    // --------------------------------------------------------
    tampilkanIndentasi(level);
    cout << "+-[SKIP]  Barang " << daftarBarang[level].nama
         << " dilewati"
         << " | Total berat=" << beratSaatIni
         << ", Total profit=" << profitSaatIni << "\n";

    // Rekursi ke barang berikutnya tanpa mengambil barang ini
    backtrack(level + 1, beratSaatIni, profitSaatIni);

    tampilkanIndentasi(level);
    cout << "  [BACKTRACK] Kembali setelah skip Barang " << daftarBarang[level].nama << "\n";
}

// ============================================================
// FUNGSI UTAMA (main)
// ============================================================
int main() {
    cout << "============================================================\n";
    cout << "   BACKTRACKING - 0/1 KNAPSACK PROBLEM\n";
    cout << "   Studi Kasus: Optimasi Pemilihan Barang Ekspedisi\n";
    cout << "============================================================\n";

    // ============================================================
    // INISIALISASI DATA BARANG
    // Sesuai soal: 4 barang dengan berat dan profit yang ditentukan
    // ============================================================
    daftarBarang = {
        {"A", 2, 40},    // Barang A: berat 2, profit 40
        {"B", 3, 50},    // Barang B: berat 3, profit 50
        {"C", 5, 100},   // Barang C: berat 5, profit 100
        {"D", 4, 60}     // Barang D: berat 4, profit 60
    };
    jumlahBarang = daftarBarang.size();
    kapasitas    = 10;

    // Tampilkan data input
    cout << "\n[DATA INPUT]\n";
    cout << "Kapasitas Knapsack : " << kapasitas << " kg\n";
    cout << "Jumlah Barang      : " << jumlahBarang << "\n\n";
    cout << left << setw(12) << "Nama"
         << setw(8)  << "Berat"
         << setw(10) << "Profit" << "\n";
    cout << string(30, '-') << "\n";
    for (auto& b : daftarBarang) {
        cout << left << setw(12) << b.nama
             << setw(8)  << b.berat
             << setw(10) << b.profit << "\n";
    }

    // ============================================================
    // JALANKAN BACKTRACKING DAN UKUR WAKTU EKSEKUSI
    // ============================================================
    cout << "\n[PROSES] Penelusuran Backtracking:\n";
    cout << string(60, '=') << "\n";
    cout << "Keterangan:\n";
    cout << "  [AMBIL]     = Barang dimasukkan ke dalam tas\n";
    cout << "  [SKIP]      = Barang tidak diambil\n";
    cout << "  [BATALKAN]  = Cabang dipangkas karena berat melebihi kapasitas\n";
    cout << "  [BACKTRACK] = Kembali ke keputusan sebelumnya\n";
    cout << string(60, '=') << "\n\n";

    auto mulai  = chrono::high_resolution_clock::now();
    backtrack(0, 0, 0);
    auto selesai = chrono::high_resolution_clock::now();

    auto durasi = chrono::duration_cast<chrono::microseconds>(selesai - mulai).count();

    // ============================================================
    // TAMPILKAN HASIL AKHIR
    // ============================================================
    int totalBerat  = 0;
    int totalProfit = 0;
    string namaBarangDipilih = "";

    for (int idx : pilihanTerbaik) {
        totalBerat  += daftarBarang[idx].berat;
        totalProfit += daftarBarang[idx].profit;
        if (!namaBarangDipilih.empty()) namaBarangDipilih += " ";
        namaBarangDipilih += daftarBarang[idx].nama;
    }

    cout << "\n";
    cout << string(40, '=') << "\n";
    cout << "       HASIL OPTIMASI (Backtracking)\n";
    cout << string(40, '=') << "\n";
    cout << "Barang Terpilih  : " << namaBarangDipilih << "\n";
    cout << "Total Berat      : " << totalBerat  << " kg\n";
    cout << "Total Profit     : " << totalProfit << "\n";
    cout << "Node Dikunjungi  : " << nodesDikunjungi << "\n";
    cout << "Waktu Eksekusi   : " << durasi << " microseconds\n";
    cout << string(40, '=') << "\n";

    return 0;
}
