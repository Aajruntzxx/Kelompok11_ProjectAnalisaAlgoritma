// ============================================================
// FILE: branch_and_bound.cpp
// JUDUL: Implementasi Branch and Bound untuk 0/1 Knapsack Problem
// STUDI KASUS: Optimasi Pemilihan Barang pada Perusahaan Ekspedisi
// ============================================================

#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>
#include <chrono>
#include <iomanip>

using namespace std;

// ============================================================
// STRUKTUR DATA BARANG
// Menyimpan atribut setiap barang yang akan dipilih
// ============================================================
struct Barang {
    string nama;   // Nama barang
    int berat;     // Berat barang (kg)
    int profit;    // Keuntungan/profit barang (rupiah/unit)
    double rasio;  // Rasio profit/berat (digunakan untuk upper bound)
};

// ============================================================
// STRUKTUR DATA NODE (Simpul Pohon Pencarian)
// Setiap node merepresentasikan keputusan untuk 1 barang
// ============================================================
struct Node {
    int level;          // Level/kedalaman dalam pohon (indeks barang ke-)
    int profit;         // Total profit yang sudah dikumpulkan
    int berat;          // Total berat yang sudah dikumpulkan
    double upperBound;  // Estimasi profit maksimum yang bisa dicapai
    vector<int> pilihan; // Daftar indeks barang yang dipilih di node ini
};

// ============================================================
// VARIABEL GLOBAL
// ============================================================
int jumlahBarang;
int kapasitas;
vector<Barang> daftarBarang;

int nodesDikunjungi = 0;   // Counter node yang dikunjungi
int nodesDipangkas  = 0;   // Counter node yang dipangkas (pruned)

// ============================================================
// FUNGSI: Hitung Upper Bound (Batas Atas)
// Menggunakan pendekatan fractional knapsack (greedy) untuk
// mengestimasi profit maksimum yang bisa diraih dari node ini.
// Jika upper bound <= profit terbaik saat ini, node dipangkas.
// ============================================================
double hitungUpperBound(Node& node) {
    // Jika berat sudah melebihi kapasitas, tidak ada solusi valid
    if (node.berat >= kapasitas) return 0;

    double bound = node.profit;
    int beratSisa = kapasitas - node.berat;
    int i = node.level + 1;

    // Ambil barang secara greedy berdasarkan rasio profit/berat
    while (i < jumlahBarang && beratSisa >= daftarBarang[i].berat) {
        beratSisa -= daftarBarang[i].berat;
        bound     += daftarBarang[i].profit;
        i++;
    }

    // Jika masih ada kapasitas tersisa, ambil sebagian barang berikutnya
    // (ini adalah estimasi — tidak boleh dilakukan di solusi nyata 0/1)
    if (i < jumlahBarang) {
        bound += (double)beratSisa * daftarBarang[i].rasio;
    }

    return bound;
}

// ============================================================
// FUNGSI: Algoritma Branch and Bound
// Menggunakan priority queue (Best-First Search) untuk menjelajahi
// node dengan upper bound tertinggi terlebih dahulu.
// ============================================================
void branchAndBound() {
    // Urutkan barang berdasarkan rasio profit/berat (descending)
    // Ini penting agar upper bound lebih akurat
    sort(daftarBarang.begin(), daftarBarang.end(),
         [](const Barang& a, const Barang& b) {
             return a.rasio > b.rasio;
         });

    cout << "\n[INFO] Urutan barang setelah diurutkan berdasarkan rasio profit/berat:\n";
    cout << left << setw(12) << "Nama"
         << setw(8)  << "Berat"
         << setw(10) << "Profit"
         << setw(10) << "Rasio" << "\n";
    cout << string(40, '-') << "\n";
    for (auto& b : daftarBarang) {
        cout << left << setw(12) << b.nama
             << setw(8)  << b.berat
             << setw(10) << b.profit
             << fixed << setprecision(2) << setw(10) << b.rasio << "\n";
    }

    // Priority queue: node dengan upper bound tertinggi diproses duluan
    // (Best-First Search)
    auto cmp = [](const Node& a, const Node& b) {
        return a.upperBound < b.upperBound;
    };
    priority_queue<Node, vector<Node>, decltype(cmp)> pq(cmp);

    // Inisialisasi node akar (root)
    Node root;
    root.level      = -1;   // Belum memilih barang apapun
    root.profit     = 0;
    root.berat      = 0;
    root.upperBound = hitungUpperBound(root);
    root.pilihan    = {};
    pq.push(root);

    int profitTerbaik = 0;
    vector<int> pilihanTerbaik;

    cout << "\n[PROSES] Penelusuran Node:\n";
    cout << string(70, '=') << "\n";
    cout << left << setw(8)  << "Node"
         << setw(8)  << "Level"
         << setw(10) << "Profit"
         << setw(8)  << "Berat"
         << setw(14) << "UpperBound"
         << "Status" << "\n";
    cout << string(70, '-') << "\n";

    int nodeId = 0;

    // ============================================================
    // LOOP UTAMA: Proses setiap node dari priority queue
    // ============================================================
    while (!pq.empty()) {
        Node curr = pq.top();
        pq.pop();
        nodesDikunjungi++;
        nodeId++;

        // Cek apakah node ini masih layak dijelajahi
        // (upper bound harus lebih besar dari solusi terbaik saat ini)
        if (curr.upperBound <= profitTerbaik) {
            nodesDipangkas++;
            cout << left << setw(8)  << nodeId
                 << setw(8)  << curr.level + 1
                 << setw(10) << curr.profit
                 << setw(8)  << curr.berat
                 << setw(14) << fixed << setprecision(2) << curr.upperBound
                 << "DIPANGKAS (bound <= best)\n";
            continue;
        }

        // Jika sudah mencapai daun pohon (semua barang sudah dipertimbangkan)
        if (curr.level == jumlahBarang - 1) {
            cout << left << setw(8)  << nodeId
                 << setw(8)  << curr.level + 1
                 << setw(10) << curr.profit
                 << setw(8)  << curr.berat
                 << setw(14) << fixed << setprecision(2) << curr.upperBound
                 << "DAUN (leaf node)\n";
            continue;
        }

        // Pindah ke barang berikutnya
        int nextLevel = curr.level + 1;

        // --------------------------------------------------------
        // CABANG KIRI: Masukkan barang ke dalam tas (include)
        // --------------------------------------------------------
        Node include;
        include.level   = nextLevel;
        include.berat   = curr.berat   + daftarBarang[nextLevel].berat;
        include.profit  = curr.profit  + daftarBarang[nextLevel].profit;
        include.pilihan = curr.pilihan;
        include.pilihan.push_back(nextLevel);

        // Hanya masukkan jika berat tidak melebihi kapasitas
        if (include.berat <= kapasitas) {
            include.upperBound = hitungUpperBound(include);

            // Perbarui solusi terbaik jika profit lebih tinggi
            if (include.profit > profitTerbaik) {
                profitTerbaik  = include.profit;
                pilihanTerbaik = include.pilihan;
            }

            // Tambahkan ke antrian hanya jika masih menjanjikan
            if (include.upperBound > profitTerbaik) {
                pq.push(include);
                cout << left << setw(8)  << ++nodeId
                     << setw(8)  << include.level + 1
                     << setw(10) << include.profit
                     << setw(8)  << include.berat
                     << setw(14) << fixed << setprecision(2) << include.upperBound
                     << "INCLUDE " << daftarBarang[nextLevel].nama << "\n";
            } else {
                nodesDipangkas++;
                cout << left << setw(8)  << ++nodeId
                     << setw(8)  << include.level + 1
                     << setw(10) << include.profit
                     << setw(8)  << include.berat
                     << setw(14) << fixed << setprecision(2) << include.upperBound
                     << "DIPANGKAS (include " << daftarBarang[nextLevel].nama << ")\n";
            }
        } else {
            nodesDipangkas++;
            cout << left << setw(8)  << ++nodeId
                 << setw(8)  << nextLevel + 1
                 << setw(10) << include.profit
                 << setw(8)  << include.berat
                 << setw(14) << setw(14) << "N/A"
                 << "DIPANGKAS (berat melebihi kapasitas)\n";
        }

        // --------------------------------------------------------
        // CABANG KANAN: Tidak masukkan barang (exclude)
        // --------------------------------------------------------
        Node exclude;
        exclude.level      = nextLevel;
        exclude.berat      = curr.berat;
        exclude.profit     = curr.profit;
        exclude.pilihan    = curr.pilihan;
        exclude.upperBound = hitungUpperBound(exclude);

        if (exclude.upperBound > profitTerbaik) {
            pq.push(exclude);
            cout << left << setw(8)  << ++nodeId
                 << setw(8)  << exclude.level + 1
                 << setw(10) << exclude.profit
                 << setw(8)  << exclude.berat
                 << setw(14) << fixed << setprecision(2) << exclude.upperBound
                 << "EXCLUDE " << daftarBarang[nextLevel].nama << "\n";
        } else {
            nodesDipangkas++;
            cout << left << setw(8)  << ++nodeId
                 << setw(8)  << exclude.level + 1
                 << setw(10) << exclude.profit
                 << setw(8)  << exclude.berat
                 << setw(14) << fixed << setprecision(2) << exclude.upperBound
                 << "DIPANGKAS (exclude " << daftarBarang[nextLevel].nama << ")\n";
        }
    }

    cout << string(70, '=') << "\n";

    // ============================================================
    // TAMPILKAN HASIL AKHIR
    // ============================================================
    int totalBerat  = 0;
    int totalProfit = 0;
    string namaBarangDipilih = "";

    for (int idx : pilihanTerbaik) {
        totalBerat  += daftarBarang[idx].berat;
        totalProfit += daftarBarang[idx].profit;
        if (!namaBarangDipilih.empty()) namaBarangDipilih += " ";
        namaBarangDipilih += daftarBarang[idx].nama;
    }

    cout << "\n";
    cout << string(40, '=') << "\n";
    cout << "       HASIL OPTIMASI (Branch and Bound)\n";
    cout << string(40, '=') << "\n";
    cout << "Barang Terpilih  : " << namaBarangDipilih << "\n";
    cout << "Total Berat      : " << totalBerat  << " kg\n";
    cout << "Total Profit     : " << totalProfit << "\n";
    cout << "Node Dikunjungi  : " << nodesDikunjungi << "\n";
    cout << "Node Dipangkas   : " << nodesDipangkas  << "\n";
}

// ============================================================
// FUNGSI UTAMA (main)
// ============================================================
int main() {
    cout << "============================================================\n";
    cout << "   BRANCH AND BOUND - 0/1 KNAPSACK PROBLEM\n";
    cout << "   Studi Kasus: Optimasi Pemilihan Barang Ekspedisi\n";
    cout << "============================================================\n";

    // ============================================================
    // INISIALISASI DATA BARANG
    // Sesuai soal: 4 barang dengan berat dan profit yang ditentukan
    // ============================================================
    daftarBarang = {
        {"A", 2, 40,  (double)40 / 2},   // Barang A: berat 2, profit 40
        {"B", 3, 50,  (double)50 / 3},   // Barang B: berat 3, profit 50
        {"C", 5, 100, (double)100 / 5},  // Barang C: berat 5, profit 100
        {"D", 4, 60,  (double)60 / 4}    // Barang D: berat 4, profit 60
    };
    jumlahBarang = daftarBarang.size();
    kapasitas    = 10;

    // Tampilkan data input
    cout << "\n[DATA INPUT]\n";
    cout << "Kapasitas Knapsack : " << kapasitas << " kg\n";
    cout << "Jumlah Barang      : " << jumlahBarang << "\n\n";
    cout << left << setw(12) << "Nama"
         << setw(8)  << "Berat"
         << setw(10) << "Profit"
         << setw(10) << "Rasio" << "\n";
    cout << string(40, '-') << "\n";
    for (auto& b : daftarBarang) {
        cout << left << setw(12) << b.nama
             << setw(8)  << b.berat
             << setw(10) << b.profit
             << fixed << setprecision(2) << setw(10) << b.rasio << "\n";
    }

    // ============================================================
    // JALANKAN ALGORITMA DAN UKUR WAKTU EKSEKUSI
    // Menggunakan std::chrono untuk presisi tinggi (microseconds)
    // ============================================================
    auto mulai  = chrono::high_resolution_clock::now();
    branchAndBound();
    auto selesai = chrono::high_resolution_clock::now();

    auto durasi = chrono::duration_cast<chrono::microseconds>(selesai - mulai).count();
    cout << "Waktu Eksekusi   : " << durasi << " microseconds\n";
    cout << string(40, '=') << "\n";

    return 0;
}
